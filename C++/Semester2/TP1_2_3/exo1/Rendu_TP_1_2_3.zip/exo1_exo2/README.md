# Instructions de compilation

## Pour tout compiler
make

## Pour compiler uniquement un exo spécifique
make calculatrice.exe
make tracer.exe

## Instructions de nettoyage
make clean

## Tester la memoire avec Valgrind
make test_calculatrice
make test_tracer
